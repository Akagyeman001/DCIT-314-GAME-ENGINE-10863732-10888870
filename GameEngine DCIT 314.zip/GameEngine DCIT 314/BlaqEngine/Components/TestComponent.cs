﻿namespace BlaqEngine.Components
{
    public class TestComponent : Component
    {
        public TestComponent()
        {
        }
    }
}