﻿using OpenTK;
using OpenTK.Mathematics;

namespace BlaqEngine.Components
{
    public interface IRenderable
    {

        void Render(Matrix4 viewMatrix, Matrix4 viewProjectionMatrix);

    }
}
