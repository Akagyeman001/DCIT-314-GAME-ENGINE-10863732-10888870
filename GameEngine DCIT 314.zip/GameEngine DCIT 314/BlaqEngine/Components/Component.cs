﻿using System.Xml.Serialization;
using BlaqEngine.SceneGraph;
using BlaqEngine.Utils.Attributes;

namespace BlaqEngine.Components
{
    public abstract class Component
    {
        [XmlIgnore]
        public GameObject GameObject { get; private set; }

        
        [XmlConstructor]
        protected Component()
        {

        }

        internal void Assign(GameObject gameObject)
        {
            this.GameObject = gameObject;
        }

        public virtual void OnInitialize()
        {

        }

        public virtual void OnStart()
        {
            
        }

        public virtual void OnUpdate(float deltaTime)
        {
            
        }

        public virtual void OnDestroy()
        {
            
        }
    }
}