﻿using NLog;

using BlaqEngine.Engine;
using BlaqEngine.Components;

namespace BlaqEngine
{
    public static class Globals
    {

        public static EngineConfiguration Config => GameEngine.Config;
        public static Logger Logger => GameEngine.Logger;

        public static GameEngine Engine => GameEngine.Instance;
        public static Camera CurrentCamera => Engine.CurrentCamera;

    }
}
