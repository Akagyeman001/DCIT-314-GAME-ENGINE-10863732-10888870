
using BlaqEngine.Models.MeshParser;
using BlaqEngine.Utils.Attributes;

namespace BlaqEngine.Models
{
    public class Model
    {

        public string FilePath;
        public Mesh Mesh;
        private bool loaded = false;


        [XmlConstructor]
        public Model()
        {

        }

        public Model(string filePath)
        {
            this.FilePath = filePath;
        }

        public void LoadResources()
        {
            if (loaded)
                return;

            loaded = true;

            Mesh = ObjParser.ParseFile(FilePath);
        }

    }
}
